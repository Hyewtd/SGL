package sgloc.core.impl.controle;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import sgloc.core.IDAO;
import sgloc.core.IFachada;
import sgloc.core.IStrategy;
import sgloc.core.aplicacao.Resultado;
import sgloc.core.impl.dao.ClienteDAO;
import sgloc.core.impl.dao.FilmeDAO;
import sgloc.core.impl.dao.FornecedorDAO;
import sgloc.core.impl.dao.LocacaoDAO;
import sgloc.core.impl.negocio.ComplementadorDtCadastro;
import sgloc.core.impl.negocio.ValidaDadosObrigatoriosFilme;
import sgloc.core.impl.negocio.VerificaSeFilmeExiste;
import sgloc.dominio.Cliente;
import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Filme;
import sgloc.dominio.Fornecedor;
import sgloc.dominio.Locacao;

public class Fachada implements IFachada {

	/**
	 * Mapa de DAOS, ser� indexado pelo nome da entidade O valor � uma inst�ncia
	 * do DAO para uma dada entidade;
	 */
	private Map<String, IDAO> daos;

	/**
	 * Mapa para conter as regras de neg�cio de todas opera��es por entidade; O
	 * valor � um mapa que de regras de neg�cio indexado pela opera��o
	 */
	private Map<String, Map<String, List<IStrategy>>> rns;

	private Resultado resultado;

	public Fachada() {

		// classe de mensageria
		resultado = new Resultado();
		/* Instanciando o Map de DAOS */
		daos = new HashMap<String, IDAO>();
		/* Instanciando o Map de Regras de Neg�cio */
		rns = new HashMap<String, Map<String, List<IStrategy>>>();

		// Populando instancias de DAOs e Strategys(Regras de Neg�cio)
		daos.put(Filme.class.getName(), new FilmeDAO());
		daos.put(Fornecedor.class.getName(), new FornecedorDAO());
		daos.put(Locacao.class.getName(), new LocacaoDAO());
		daos.put(Cliente.class.getName(), new ClienteDAO());

		// Criando inst�ncias das REGRAS DE NEG�CIO a serem utilizados
		ValidaDadosObrigatoriosFilme vlDadosObrigatoriosFilme = new ValidaDadosObrigatoriosFilme();
		VerificaSeFilmeExiste vExisteFilme = new VerificaSeFilmeExiste();

		// ######################LISTA REGRAS###########################
		// #############################################################

		/* Populando lista de regras Filmes */
		List<IStrategy> rnsSalvarFilme = new ArrayList<IStrategy>();
		rnsSalvarFilme.add(vlDadosObrigatoriosFilme);
		rnsSalvarFilme.add(vExisteFilme);
		rnsSalvarFilme.add(new ComplementadorDtCadastro());
		
		/* Populando lista de regras Filmes */
		List<IStrategy> rnsSalvarCliente = new ArrayList<IStrategy>();
		rnsSalvarCliente.add(new ComplementadorDtCadastro());
		
		/* Populando lista de regras Locacao */
		List<IStrategy> rnsSalvarLocacao = new ArrayList<IStrategy>();

		// ######################  FILMES - SALVAR ###########################
		// #############################################################

		/*
		 * Criando map que pode conter todas as regras de FILME quando a
		 * operacao for SALVAR
		 */

		Map<String, List<IStrategy>> rnsFilmes = new HashMap<>();
		// adicionando regras ao MAP
		rnsFilmes.put("SALVAR", rnsSalvarFilme);
		
		//###################### ALTERAR ###########################
	    //#############################################################
		
		/* Criando lista de regras de FILMES ao Atualizar */
		List<IStrategy> rnsAtualizarFilme = new ArrayList<>();
		// rnsAtualizarFilme.add(new VerificaSeFilmeExiste());
		// rnsAtualizarFilme.add(new ValidadorAtualizacaoFilme());
		
		rnsFilmes.put("ATUALIZAR", rnsAtualizarFilme);
		
		//###################### CONSULTAR ###########################
	    //#############################################################
		
		/* Criando lista de regras de FILMES ao Atualizar */
		List<IStrategy> rnsConsultarFilme = new ArrayList<>();
		// rnsAtualizarFilme.add(new VerificaSeFilmeExiste());
		// rnsAtualizarFilme.add(new ValidadorAtualizacaoFilme());
		
		rnsFilmes.put("CONSULTAR", rnsConsultarFilme);
		
		// ######################  CLIENTES - SALVAR ###########################
		// #############################################################

		/*
		 * Criando map que pode conter todas as regras de CLIENTE quando a
		 * operacao for SALVAR
		 */

		Map<String, List<IStrategy>> rnsClientes = new HashMap<>();
		// adicionando regras ao MAP
		rnsClientes.put("SALVAR", rnsSalvarCliente);

		//###################### LOCACAO - SALVAR ###########################
	    //#############################################################
		
		/*
		 * Criando map que pode conter todas as regras de LOCACAO quando a
		 * operacao for SALVAR
		 */

		Map<String, List<IStrategy>> rnsLocacoes = new HashMap<>();
		// adicionando regras ao MAP
		rnsLocacoes.put("SALVAR", rnsSalvarLocacao);

		

		//###################### REGRAS MAP ###########################
		//#############################################################
		
		// adicionando regras ao MAP
	    rns.put(Filme.class.getName(), rnsFilmes);
	    rns.put(Locacao.class.getName(), rnsLocacoes);
	    rns.put(Cliente.class.getName(), rnsClientes);

	}
	// --------------------------------------------------------------------------------------------------------
	// #################### ###################################################################################
	// --------------------------------------------------------------------------------------------------------

	@Override
	public Resultado salvar(EntidadeDominio entidade) {
		resultado = new Resultado();
		String nmClasse = entidade.getClass().getName();

		String msg = executarRegras(entidade, "SALVAR");

		if (msg == null) {
			IDAO dao = daos.get(nmClasse);
			try {
				dao.salvar(entidade);
				List<EntidadeDominio> entidades = new ArrayList<EntidadeDominio>();
				entidades.add(entidade);
				resultado.setEntidades(entidades);
			} catch (SQLException e) {
				e.printStackTrace();
				resultado.setMsg("N�o foi poss�vel realizar o registro!");

			}
		} else {
			resultado.setMsg(msg);

		}

		return resultado;
	}

	@Override
	public Resultado alterar(EntidadeDominio entidade) {
		resultado = new Resultado();
		String nmClasse = entidade.getClass().getName();

		String msg = executarRegras(entidade, "ALTERAR");

		if (msg == null) {
			IDAO dao = daos.get(nmClasse);
			try {
				dao.alterar(entidade);
				List<EntidadeDominio> entidades = new ArrayList<EntidadeDominio>();
				entidades.add(entidade);
				resultado.setEntidades(entidades);
			} catch (SQLException e) {
				e.printStackTrace();
				resultado.setMsg("Nao foi possivel realizar o registro!");

			}
		} else {
			resultado.setMsg(msg);

		}

		return resultado;

	}

	@Override
	public Resultado excluir(EntidadeDominio entidade) {
		resultado = new Resultado();
		String nmClasse = entidade.getClass().getName();

		String msg = executarRegras(entidade, "EXCLUIR");

		if (msg == null) {
			IDAO dao = daos.get(nmClasse);
			try {
				dao.excluir(entidade);
				List<EntidadeDominio> entidades = new ArrayList<EntidadeDominio>();
				entidades.add(entidade);
				resultado.setEntidades(entidades);
			} catch (SQLException e) {
				e.printStackTrace();
				resultado.setMsg("Nao foi possivel realizar o registro!");

			}
		} else {
			resultado.setMsg(msg);

		}

		return resultado;

	}

	@Override
	public Resultado consultar(EntidadeDominio entidade) {
		resultado = new Resultado();
		String nmClasse = entidade.getClass().getName();

		String msg = executarRegras(entidade, "CONSULTAR");

		if (msg == null) {
			IDAO dao = daos.get(nmClasse);
			try {

				resultado.setEntidades(dao.consultar(entidade));
			} catch (SQLException e) {
				e.printStackTrace();
				resultado.setMsg("Não foi possível realizar a consulta!");

			}
		} else {
			resultado.setMsg(msg);

		}

		return resultado;

	}

	@Override
	public Resultado visualizar(EntidadeDominio entidade) {
		resultado = new Resultado();
		resultado.setEntidades(new ArrayList<EntidadeDominio>(1));
		resultado.getEntidades().add(entidade);
		return resultado;

	}

	private String executarRegras(EntidadeDominio entidade, String operacao) {
		String nmClasse = entidade.getClass().getName();
		StringBuilder msg = new StringBuilder();

		Map<String, List<IStrategy>> regrasOperacao = rns.get(nmClasse);

		if (regrasOperacao != null) {
			List<IStrategy> regras = regrasOperacao.get(operacao);

			if (regras != null) {
				for (IStrategy s : regras) {
					String m = s.processar(entidade);

					if (m != null) {
						msg.append(m);
						msg.append("\n");
					}
				}
			}

		}

		if (msg.length() > 0)
			return msg.toString();
		else
			return null;
	}
	
	//=========================================
	/**
	 * Método criado para consulta das locacoes realizadas pelo cliente
	 * @param entidade
	 * @return
	 * @throws SQLException 
	 */
	public Resultado consultarLocacaoPorCliente(EntidadeDominio entidade) {
		resultado = new Resultado();
		String nmClasse = entidade.getClass().getName();
		Cliente c = new Cliente();
		
		String msg = executarRegras(entidade, "CONSULTARLOC");

		
		if (msg == null) {
			IDAO dao = daos.get(nmClasse);
				
			try {
				dao.consultar(c);
				resultado.setEntidades(dao.consultar(entidade));
			} catch (SQLException e) {
				e.printStackTrace();
				resultado.setMsg("Não foi possível realizar a consulta!");

			}
		} else {
			resultado.setMsg(msg);

		}

		return resultado;

	}

}
