package sgloc.core.impl.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import sgloc.dominio.Cliente;
import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Filme;
import sgloc.dominio.Locacao;
import sgloc.dominio.Status;

public class LocacaoDAO extends AbstractJdbcDAO{
	
	//construtor default 
	public LocacaoDAO() {
		super(null,null);
	}
	
	
	public LocacaoDAO(Connection connection, String table, String idTable) {
		super(connection, table, idTable);
	}

	@Override
	public void salvar(EntidadeDominio entidade) throws SQLException {
		Locacao locacao = (Locacao) entidade;
		
	    openConnection();
	    connection.setAutoCommit(false);
		
		try{
			StringBuilder sql = new StringBuilder();
			
			sql.append("INSERT INTO tb_locacao ");
			sql.append("(datalocacao,cliente_id,total,tipopagamento,datanormal,posicao,status,data_devolucao) ");
			sql.append("VALUES(?,?,?,?,?,?,?,?)");
			
			PreparedStatement pst = connection.prepareStatement(sql.toString(),Statement.RETURN_GENERATED_KEYS);
			
			Timestamp time = new Timestamp(locacao.getDataLocacao().getTimeInMillis());
			pst.setTimestamp(1, time);
			pst.setInt(2, locacao.getCliente().getId());
			pst.setDouble(3, locacao.valorTotal());
			pst.setString(4, locacao.getTipoPagamento());
			pst.setDate(5, new Date(locacao.getDataNormal().getTime()));
			pst.setString(6, locacao.getStatus().get(0).name());
			//pst.setString(7, locacao.getStatus().get(1).AGUARGANDO_DEVOLUCAO);
			pst.setString(7, locacao.getStatus().get(1).name());
			Timestamp dataDevolucao = new Timestamp(locacao.getDataDevolucao().getTimeInMillis());
			pst.setTimestamp(8, dataDevolucao);
			
			pst.execute();
			
			ResultSet rs = pst.getGeneratedKeys();
			
			rs.next();
			
			locacao.setId(rs.getInt("idLocacao"));
			
			sql = new StringBuilder();
			
			sql.append("INSERT INTO tb_locacao_filme ");//relacionamento Locacao_Filme
			sql.append("(id_locacao,id_filme) ");
			sql.append("VALUES(?,?) ");
			
			for(Filme f : locacao.getItens()){
				
				pst = connection.prepareStatement(sql.toString());
				pst.setInt(1, locacao.getId());
				pst.setInt(2,f.getId());
				
				pst.execute();
			}
			
			//if(!ctrlTransaction)
				connection.commit();
		}
		catch(SQLException ex)
		{
			connection.rollback();
			
			ex.printStackTrace();
			
			throw new SQLException("Erro ao gravar locacao",ex);
		}
		finally {
			//if(!ctrlTransaction)
				connection.close();
		}
	} 

	@Override
	public void alterar(EntidadeDominio entidade) throws SQLException {
		
		
		
	}

	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidade) throws SQLException {
		
		PreparedStatement pst = null;
        Locacao loc = (Locacao) entidade;
        List<EntidadeDominio> entidades = new ArrayList<>();
        int mes, ano;
        StringBuilder sql = new StringBuilder();
        String sql1 = null;
      try{  
    	   openConnection();
            if (loc.getDataNormal() != null)
            {
                sql.append("SELECT DISTINCT ");
                sql.append("l.idLocacao, c.nome, l.dataLocacao, l.tipoPagamento, l.posicao, l.status, l.data_devolucao ");
                sql.append("FROM tb_locacao AS l,  tb_cliente as c ");
                sql.append("WHERE l.cliente_id = ? and ");
                sql.append("date_part('month',l.datanormal) = ? and ");
                sql.append("date_part('year',l.datanormal) = ?");
                
              //pegando mes e ano da data!
                Calendar cl = Calendar.getInstance();
                cl.setTime(loc.getDataNormal());
                mes = cl.get(Calendar.MONTH) + 1;
                ano = cl.get(Calendar.YEAR);
                //fim do ano e mes!
                
                pst.setInt(1, loc.getCliente().getId());
                pst.setInt(2, mes);
                pst.setInt(3, ano);
                
            } else if(loc.getItens() != null) { //Não contem nenhum item??
            	
            	FilmeDAO daoFilme = new FilmeDAO(connection);
    			List<EntidadeDominio> filmes = daoFilme.consultar(new Filme());
    			
    			ClienteDAO daoCliente = new ClienteDAO(connection);
    			Cliente cliente = (Cliente) daoCliente.consultar(loc.getCliente()).get(0);
    			loc.setCliente(cliente);
    			
    			/**
            	 * TODO --> Fazer a query para retornar as pendencias do cliente!
            	 */
            	sql.append("SELECT DISTINCT ");
                sql.append("l.idLocacao, l.situacaoCliente, c.nome, l.dataLocacao, l.tipoPagamento, l.posicao, l.status, l.data_devolucao ");
                sql.append("FROM tb_locacao AS l,  tb_cliente as c ");
                sql.append("WHERE l.cliente_id = ?");
			 }
            	
                pst = connection.prepareStatement(sql.toString());

                ResultSet rs = pst.executeQuery();  //pegando resultado da consulta!

                while (rs.next())    //prossiga ate que nao tenha mais cursor!
                {
                    Locacao locacao = new Locacao();
                    locacao.setId(rs.getInt("idLocacao"));
                    //locacao.getCliente().setNome("nome");
                    
                    Calendar dtLoc = Calendar.getInstance();
                    dtLoc.setTimeInMillis(rs.getDate("dataLocacao").getTime());
                    locacao.setDataLocacao(dtLoc);
                    locacao.setTipoPagamento(rs.getString("tipoPagamento"));
                    locacao.setStatus(Arrays.asList(Status.valueOf(rs.getString("posicao")), Status.valueOf(rs.getString("status"))));
                    
                    Calendar dtDev = Calendar.getInstance();
                    dtDev.setTimeInMillis(rs.getDate("data_devolucao").getTime());
                    locacao.setDataDevolucao(dtDev);

                    entidades.add(locacao); // colocando os pedidos!
                }

                return entidades;   //retornando os pedidos!
            
   //-----------------------------------------------------------------------
            } catch (SQLException e) {
    			e.printStackTrace();
    		}
          finally{
        	  connection.close();        	  
          }
    		return null;
    	}
//----------------------------------------------------	
	/**
	 * Verifica se o cliente locou um filme mais de uma vez
	 * @param locacao
	 * @return
	 * @throws SQLException 
	 */
	public boolean isPrimeiraLocacaoCliente(EntidadeDominio entidade) throws SQLException{
		
		Locacao locacao = (Locacao) entidade;
		
	    openConnection(); //abrindo conexao com o banco
	    
		try{
			StringBuilder sql = new StringBuilder();
			
			sql.append("SELECT count(cliente_id) as qtde FROM tb_locacao ");
			sql.append("WHERE cliente_id = ? ");
			sql.append("LIMIT 2");
			
			PreparedStatement pst = connection.prepareStatement(sql.toString());
			
			pst.setInt(1, locacao.getCliente().getId());
			
			ResultSet rs = pst.executeQuery();		
			
			rs.next();
			
			if(rs.getInt("qtde") > 1)
				return false;
			else
				return true;
		}
		catch(SQLException ex){
			ex.printStackTrace();
			throw new SQLException("Erro ao verificar se Cliente ja locou",ex);
		}
		finally {
			connection.close();
		}
	}

}
