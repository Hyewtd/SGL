package sgloc.core.impl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Estoque;

public class EstoqueDAO extends AbstractJdbcDAO{

	public EstoqueDAO(Connection connection, String table, String idTable) {
		super(connection, table, idTable);
		// TODO Auto-generated constructor stub
	}
	
	//construtor default
	public EstoqueDAO() { 
		super("","");
		}

	@Override
	public void salvar(EntidadeDominio entidade) throws SQLException {
		Estoque estoque = (Estoque) entidade;
		
		if(connection != null && connection.isClosed())	{
			openConnection();
			connection.setAutoCommit(false);
		}
		
		try{
			StringBuilder sql = new StringBuilder();
			
			sql.append("INSERT INTO tb_estoque (id_filme,qtde_filme,qtde_locados) ");
			sql.append("VALUES (?,?,?)");
			
			PreparedStatement pst = connection.prepareStatement(sql.toString());
			
			pst.setInt(1, estoque.getFilme().getId());
			pst.setInt(2, estoque.getQtdeFilme());
			pst.setInt(3, estoque.getQtdeLocado());
			
			pst.execute();
			
			if(!ctrlTransaction) //se nao existir uma transacao manda commitar!
				connection.commit();
		}
		catch(SQLException ex){
			throw new SQLException("Erro ao salvar no estoque",ex);
		}
		finally{
			if(!ctrlTransaction){
				connection.close();
			}
		}
	}

	@Override
	public void alterar(EntidadeDominio entidade) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidade) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}