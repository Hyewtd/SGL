package sgloc.core.impl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import sgloc.core.IDAO;
import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Estoque;
import sgloc.dominio.Filme;
import sgloc.dominio.Fornecedor;
import sgloc.dominio.Midia;

public class FilmeDAO extends AbstractJdbcDAO {

	public FilmeDAO() {
		
		super("tb_filme", "idfilme");		
	}
	
		
	public FilmeDAO(Connection connection) {
		// TODO Auto-generated constructor stub
		super(connection,null,null);
	}


	public void salvar(EntidadeDominio entidade){
		openConnection();
		PreparedStatement pst = null;
		Filme filme = (Filme) entidade;
		Fornecedor fr = filme.getFornecedor();
		Midia md = filme.getMidia();
		
		//Midia midia = new Midia();
		//Fornecedor fornecedor = filme.getFornecedor();
		//Midia midia = filme.getTipoMidia();
		

		try {
			connection.setAutoCommit(false);
			
			//criando novo DAO e passando conexao!
			FornecedorDAO fornDAO = new FornecedorDAO(connection);
			fornDAO.salvar(fr);
			
			//TODO Mida Agora eh um Enum!!
			/*MidiaDAO mdDAO = new MidiaDAO(connection);
			mdDAO.salvar(md);*/
			
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO tb_filme(titulo, tituloOriginal, atorPrincipal, produtora, anoLancamento, ");
			sql.append("for_id, genero, midia, qntddEntrada, custo, totalCompra, totalDisponivel, ");
			sql.append("status, dt_cadastro) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			pst = connection.prepareStatement(sql.toString(),Statement.RETURN_GENERATED_KEYS);

			pst.setString(1, filme.getTitulo());
			pst.setString(2, filme.getTituloOriginal());
			pst.setString(3, filme.getAtorPrincipal());
			pst.setString(4, filme.getProdutora());
			pst.setString(5, filme.getAnoLancamento());
			pst.setInt(6, fr.getId());
			pst.setString(7, filme.getGenero());
			pst.setString(8, md.getTipoMidia()); //pega a descricao do Enum
			pst.setInt(9, filme.getQntddEntrada());
			pst.setDouble(10, filme.getCusto());
			pst.setDouble(11, filme.getTotalCompra());
			pst.setInt(12, filme.getTotalDisponivel());
			pst.setInt(13, 1);	// gravando filme como ATIVO no bd;		
			
			
			Timestamp time = new Timestamp(filme.getDtCadastro().getTime());
			pst.setTimestamp(14, time);
			
			pst.executeUpdate();
			
			ResultSet rs = pst.getGeneratedKeys();
						
			if(rs.next())
				filme.setId(rs.getInt("idfilme"));
			
			//gravando o filme no estoque
			IDAO dao = new EstoqueDAO(connection, null, null);
			
			dao.salvar(new Estoque(filme,filme.getQntddEntrada(),0));
			
			connection.commit();
			
			 
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

//##############################################################################################################	
	
	/**
	 * TODO Descri��o do M�todo
	 * 
	 * @param entidade
	 * @see fai.dao.IDAO#alterar(fai.domain.EntidadeDominio)
	 */
	@Override
	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Filme filme = (Filme) entidade;

		try {
			connection.setAutoCommit(false);
		
			StringBuilder sql = new StringBuilder();
			
			if (filme.getTotalDisponivel() != 0) //filme alocado?
            {
                sql.append("UPDATE tb_filme SET ");
                sql.append("totaldisponivel = ? ");
                sql.append("WHERE ID = ?");

                pst = connection.prepareStatement(sql.toString());

                pst.setInt(1, filme.getTotalDisponivel());
                pst.setInt(2, filme.getId());
            } 
			
            else
            {
			
			sql.append("UPDATE tb_filme SET titulo=?, tituloOriginal=?, produtora=? ");
			sql.append("WHERE idfilme=?");

			pst = connection.prepareStatement(sql.toString());
			pst.setString(1, filme.getTitulo());
			pst.setString(2, filme.getTituloOriginal());
			pst.setString(3, filme.getProdutora());
			pst.setInt(4, filme.getId()); //pega ID do item a ser alterado;
			
     }//ELSE
			
			pst.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
//##############################################################################################################
	/**
	 * TODO Descri��o do M�todo
	 * 
	 * @param entidade
	 * @return
	 * @see fai.dao.IDAO#consulta(fai.domain.EntidadeDominio)
	 */
	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		Filme filme = (Filme) entidade;
		String sql = null;

		if (filme.getTitulo() == null) {
			filme.setTitulo("");
		}

		if (filme.getId() == null && filme.getTitulo().equals("")) {
			sql = "SELECT * FROM tb_filme";
		} else if (filme.getId() != null && filme.getTitulo().equals("")) {
			sql = "SELECT * FROM tb_filme WHERE idfilme=?";
		} else if (filme.getId() == null && !filme.getTitulo().equals("")) {
			sql = "SELECT * FROM tb_filme WHERE titulo ilike ?";
		} 

		try {
			openConnection();
			pst = connection.prepareStatement(sql);

			if (filme.getId() != null && filme.getTitulo().equals("")) {
				pst.setInt(1, filme.getId());
			} else if (filme.getId() == null && !filme.getTitulo().equals("")) {
				pst.setString(1, "%" + filme.getTitulo() + "%");
			}

			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> filmes = new ArrayList<EntidadeDominio>();
			
			while (rs.next()) {
				Filme f = new Filme();
				f.setId(rs.getInt("idfilme"));
				f.setTitulo(rs.getString("titulo"));
				f.setTituloOriginal(rs.getString("tituloOriginal"));
				f.setProdutora(rs.getString("produtora"));

				java.sql.Date dtCadastroEmLong = rs.getDate("dt_cadastro");
				Date dtCadastro = new Date(dtCadastroEmLong.getTime());
				f.setDtCadastro(dtCadastro);
				filmes.add(f);
			}
			return filmes;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}



//##############################################################################################################

	@Override
	public void excluir(EntidadeDominio entidade) throws SQLException
	{
		PreparedStatement pst = null;
		StringBuilder sql = new StringBuilder();
		Filme filme = (Filme) entidade;
		
		try
		{
			 if(connection == null || connection.isClosed())
	                openConnection();   //abrindo conexao com banco de dados!
	            
			 connection.setAutoCommit(false);  //setando auto commit para false!
	            
	            sql.append("UPDATE tb_filme SET ");
	            sql.append("STATUS = 0 ");
	            sql.append("WHERE idfilme = ?");
	            
	            pst = connection.prepareStatement(sql.toString());
	            
	            pst.setInt(1, filme.getId());
	            
	            pst.executeUpdate();
	            
	            connection.commit();  //commitando as alteracoes
	        }
	        catch(SQLException ex)
	        {
	            ex.printStackTrace();
	            try
	            {
	            	connection.rollback();
	            }
	            catch(SQLException ex1)
	            {
	                ex1.printStackTrace();
	            }
	        }
	        finally
	        {
	            try
	            {
	            	connection.close();
	            }
	            catch(SQLException ex)
	            {
	                ex.printStackTrace();
	            }
	        }
	    }// excluir


}//FILMEDAO
