package sgloc.core.impl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Fornecedor;

public class FornecedorDAO extends AbstractJdbcDAO {


	protected FornecedorDAO(String table, String idTable) {
		super("tb_fornecedor", "idfor");	
	}
	
	public FornecedorDAO(Connection cx){
		super(cx, "tb_fornecedor", "idfor");
		ctrlTransaction = false;
	}
	
	public FornecedorDAO(){
		super("tb_fornecedor", "idfor");			
	}

	@Override
	public void salvar(EntidadeDominio entidade) throws SQLException {
		//A conexao est� fechada??
		if (connection == null || connection.isClosed()) {
			openConnection();
			connection.setAutoCommit(false);//seta o autocommit para false
		//Sim!
		}
		PreparedStatement pst = null;
		Fornecedor forn = (Fornecedor) entidade;
		StringBuilder sql = new StringBuilder();

		sql.append("INSERT INTO tb_fornecedor(rzsocial, cnpj)");
		sql.append("VALUES (?, ?)");
		
		try {
			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);

			pst.setString(1, forn.getNome());
			pst.setString(2, forn.getCnpj());
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();
			int idForn = 0;
			if (rs.next())
				idForn = rs.getInt(1);
			forn.setId(idForn);

			connection.commit();

		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();

		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally {
			if (ctrlTransaction) {
				try {
					pst.close();
					if (ctrlTransaction)
						connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void alterar(EntidadeDominio entidade) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidade) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
