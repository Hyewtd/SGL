package sgloc.core.impl.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import sgloc.dominio.EntidadeDominio;

public class MultaDAO extends AbstractJdbcDAO {

	//construtor default 
			public MultaDAO() {
				super(null,null);
			}
			
			
			public MultaDAO(Connection connection, String table, String idTable) {
				super(connection, table, idTable);
			}
	
	@Override
	public void salvar(EntidadeDominio entidade) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void alterar(EntidadeDominio entidade) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidade) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
