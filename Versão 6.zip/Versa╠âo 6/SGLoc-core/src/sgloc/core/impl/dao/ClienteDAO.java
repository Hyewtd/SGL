package sgloc.core.impl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import sgloc.core.IDAO;
import sgloc.dominio.Cliente;
import sgloc.dominio.Endereco;
import sgloc.dominio.EntidadeDominio;

public class ClienteDAO extends AbstractJdbcDAO {

	public ClienteDAO(Connection connection, String table, String idTable) {
		super(connection, table, idTable);
	}

	public ClienteDAO(String table, String idTable) {
		super(table, idTable);
	}

	public ClienteDAO(Connection connection) {
		super(connection, "tb_cliente", "idCliente");
	}

	public ClienteDAO() {

		super("tb_cliente", "idCliente");
	}

	@Override
	public void salvar(EntidadeDominio entidade) throws SQLException {

		openConnection();
		PreparedStatement pst = null;
		Cliente cliente = (Cliente) entidade;
		Endereco end = cliente.getEndereco();

		try {
			connection.setAutoCommit(false);

			// criando novo DAO e passando conexao!
			IDAO endDAO = new EnderecoDAO(connection, "tb_cliente", "idCliente");
			endDAO.salvar(end);//salva o endereco no banco de dados primeiro!!
            //se nao conseguir salvar, vai gerar uma exception

			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO tb_cliente(nome, cpf, mail, celular, profissao, ");
			sql.append("sexo, status, end_id, dt_nasc, ");
			sql.append("dt_cadastro, situacaoCliente) VALUES (?,?,?,?,?,?,?,?,?,?,?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);

			pst.setString(1, cliente.getNome());
			pst.setString(2, cliente.getCpf());
			pst.setString(3, cliente.getMail());
			pst.setString(4, cliente.getCelular());
			pst.setString(5, cliente.getProfissao());
			pst.setString(6, cliente.getSexo());
			pst.setInt(7, 1);
			pst.setInt(8, end.getId());
			pst.setTimestamp(9, new Timestamp(cliente.getDtNasc().getTimeInMillis()));

			Timestamp time = new Timestamp(cliente.getDtCadastro().getTime());
			pst.setTimestamp(10, time);
			
			pst.setInt(11, 0); // aqui dizendo que o Cliente acabou de ser cadastrado e nao possui NENHUMA locacao!

			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			if (rs.next())
				cliente.setId(rs.getInt("idCliente"));

			connection.commit();

		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	// ===============================================================================================

	@Override
	public void alterar(EntidadeDominio entidade) throws SQLException {

		openConnection();
		PreparedStatement pst = null;
		// Cliente cliente = (Cliente) entidade;

		try {
			connection.setAutoCommit(false);

			// atualizando dados do endereco
			// aaaIDAO dao = new EnderecoDAO(connection, "tb_cliente",
			// "idcliente");

			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE tb_filme SET ");
			sql.append("nome = ?,");
			sql.append("NOME = ?,");
			sql.append("NOME = ?,");

			pst = connection.prepareStatement(sql.toString());
			// pst.setString(1, filme.getTitulo());
			// pst.setString(2, filme.getTituloOriginal());
			// pst.setString(3, filme.getProdutora());
			// pst.setInt(4, filme.getId()); //pega ID do item a ser alterado;

			pst.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidade) throws SQLException {
		
		PreparedStatement pst = null;

		Cliente cliente = (Cliente) entidade;
		String sql = null;

		if (cliente.getNome() == null) {
			cliente.setNome("");
		}
		
		if (cliente.getId() == null && cliente.getNome().equals("")) {
			sql = "SELECT * FROM tb_cliente";
		} else if (cliente.getId() != null && cliente.getNome().equals("")) {
			sql = "SELECT * FROM tb_cliente WHERE idcliente=?";
		} else if (cliente.getId() == null && !cliente.getNome().equals("")) {
			sql = "SELECT * FROM tb_cliente WHERE nome ilike ?";
		}

		try {
			openConnection();
			pst = connection.prepareStatement(sql);

			if (cliente.getId() != null && cliente.getNome().equals("")) {
				pst.setInt(1, cliente.getId());
				
			} else if(cliente.getCpf() != null){
				sql += " WHERE cpf = ?";
				pst.setString(1,cliente.getCpf());
				
			}else if(cliente.getId() == null && !cliente.getNome().equals("")) {
				pst.setString(1, "%" + cliente.getNome() + "%");
			}
			

			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> clientes = new ArrayList<EntidadeDominio>();
			
			while (rs.next()) {
				Cliente c = new Cliente();
				c.setId(rs.getInt("idcliente"));
				c.setNome(rs.getString("nome"));
				c.setCpf(rs.getString("cpf"));

				java.sql.Date dtCadastroEmLong = rs.getDate("dt_cadastro");
				Date dtCadastro = new Date(dtCadastroEmLong.getTime());
				c.setDtCadastro(dtCadastro);
				clientes.add(c);
			}
			return clientes;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Pensar nesse método depois! \o/
	 * @param entidade
	 * @return
	 */
	public String montaCorpoPesquisa(EntidadeDominio entidade){
		
		return null;
	}

}
