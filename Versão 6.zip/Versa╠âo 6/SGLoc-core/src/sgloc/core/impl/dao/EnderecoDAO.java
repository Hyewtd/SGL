package sgloc.core.impl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import sgloc.dominio.Endereco;
import sgloc.dominio.EntidadeDominio;

public class EnderecoDAO extends AbstractJdbcDAO {
	
	public EnderecoDAO(Connection connection, String table, String idTable)
    {
        super(connection, table, idTable);
    }
	
	protected EnderecoDAO(String table, String idTable) {
		super("tb_endereco", "idEnd");	
	}
	
	public EnderecoDAO(Connection cx){
		super(cx, "tb_endereco", "idEnd");
		ctrlTransaction = false;
	}
	
	public EnderecoDAO(){
		super("tb_endereco", "idEnd");			
	}

    
	@Override
	public void salvar(EntidadeDominio entidade) throws SQLException {
		
		PreparedStatement pst = null;
        try
        {
            if (connection == null || connection.isClosed())
            {
                openConnection();   // abrindo conexao
                connection.setAutoCommit(false);//seta o autocommit para false
        		//Sim!
            }
            //criando sql para inser no banco
            StringBuilder sql = new StringBuilder();

            sql.append("INSERT INTO TB_ENDERECO ");
            sql.append("(LOGRADOURO,CEP,BAIRRO,ESTADO,CIDADE,NUMERO) ");
            sql.append(" VALUES (?,?,?,?,?,?) ");

            //setando auto commit para false
           // connection.setAutoCommit(false);

            //criando caminho para conexao no banco de dados
            pst = connection.prepareStatement(sql.toString(),
                    Statement.RETURN_GENERATED_KEYS);   //retorna a ultima chave inserida no banco

            //setando parametros do insert
            pst.setString(1, ((Endereco) entidade).getLogradouro());
            pst.setString(2, ((Endereco) entidade).getCEP());
            pst.setString(3, ((Endereco) entidade).getBairro());
            pst.setString(4, ((Endereco) entidade).getEstado());
            pst.setString(5, ((Endereco) entidade).getCidade());
            pst.setString(6,((Endereco)entidade).getNumero());

            pst.executeUpdate();  //executando a query no banco de dados

            //pegando id da ultima insercao no banco
            ResultSet rs = pst.getGeneratedKeys();
            
            
			
			connection.commit();


            //se conseguir interar pelo menos 1 vez
            if (rs.next())
            {//conseguiu iterar
                entidade.setId(rs.getInt("idend"));
            }
            //confirmando alteracoes no banco
            //connection.commit();
        } catch (SQLException ex)
        {
            try
            {
                connection.rollback();    //nao efetua as alteracoes no banco
            } catch (SQLException ex1)
            {
                ex1.printStackTrace();  //imprime o codigo de erro no console
                throw new SQLException(ex1);
            }
            ex.printStackTrace();
            throw new SQLException(ex);
        } finally
        {
            if (!ctrlTransaction)
            {
                try
                {
                    pst.close();

                    if (!ctrlTransaction)
                    {
                        connection.close();    //fecha a conexao com o banco
                    }
                } catch (SQLException ex)
                {
                    ex.printStackTrace();
                }
            }
        }
    }

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	

	@Override
	public void alterar(EntidadeDominio entidade) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidade) throws SQLException {
		
		PreparedStatement pst = null;   //abrindo caminho para o banco de dados
        List<EntidadeDominio> entidades = new ArrayList<>();
        try
        {
            if(connection == null || connection.isClosed())
            {
                openConnection();//abre a conexao se ela estiver fechada
            }
            
            connection.setAutoCommit(false);  //setando auto commit para false
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM tb_endereco ");
            sb.append("WHERE IDEND = (?)");
            
            pst = connection.prepareStatement(sb.toString());
            
            pst.setInt(1,entidade.getId()); //setando parametro
            
            ResultSet rs = pst.executeQuery();  //pegando resultado da consulta
            
            if(rs.next())
            {
                Endereco end = new Endereco();
                end.setId(rs.getInt("idend"));
                end.setLogradouro(rs.getString("logradouro"));
                end.setBairro(rs.getString("bairro"));
                end.setCEP(rs.getString("cep"));
                end.setEstado(rs.getString("estado"));
                end.setCidade(rs.getString("cidade"));
                end.setNumero(rs.getString("numero"));
                entidades.add(end);
            }
            return entidades;
        }
        catch(SQLException ex)
        {
            try
            {
            	connection.rollback();
            } 
            catch (SQLException ex1)
            {
                ex1.printStackTrace();
            }
        }
        finally
        {
            try 
            {
                if(ctrlTransaction)
                pst.close();
                
                if(ctrlTransaction)
                connection.close();
            }
            catch (SQLException ex) 
            {
                ex.printStackTrace();
            }
        }
        return entidades;
    }
}