package sgloc.core.impl.negocio;

import sgloc.core.IStrategy;
import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Filme;
import sgloc.dominio.Fornecedor;
import sgloc.dominio.Midia;

public class ValidaDadosObrigatoriosFilme implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {

		if(entidade instanceof Filme){
			Filme filme = (Filme)entidade;
			Fornecedor fr = filme.getFornecedor();
			Midia md = filme.getMidia();
			
			String titulo = filme.getTitulo();
			String tituloOriginal = filme.getTituloOriginal();
			String atorPrincipal = filme.getAtorPrincipal();
			String produtora = filme.getProdutora();
			String anoLancamento = filme.getAnoLancamento();
			String nome = filme.getFornecedor().getNome();
			String cnpj = filme.getFornecedor().getCnpj();
			String genero = filme.getGenero();
			String tipoMidia = filme.getMidia().getTipoMidia();
			Integer qntddEntrada = filme.getQntddEntrada();
			Double custo = filme.getCusto();
			Double totalCompra = filme.getTotalCompra();
			Integer totalDisponivel = filme.getTotalDisponivel();
			
			
			if(titulo == null || tituloOriginal == null || atorPrincipal==null || produtora == null
				|| anoLancamento == null || nome == null || cnpj == null || genero == null || tipoMidia == null
				|| qntddEntrada == null || custo == null || totalCompra == null || totalDisponivel == null){
				return "TODOS os campos s�o de preenchimento obrigat�rio!";
			}
			
			if(titulo.trim().equals("") || tituloOriginal.trim().equals("") || 
					produtora.trim().equals("")|| nome.trim().equals("")|| cnpj.trim().equals("")
					|| genero.trim().equals("") || tipoMidia.trim().equals("") ){
				return "T�tuolo, T�tulo Original, Produtora e Fornecedor s�o de preenchimento obrigat�rio!";
			}
			
		}else{
			return "Deve ser registrado um Filme!";
		}
		
		return null;
	}

}
