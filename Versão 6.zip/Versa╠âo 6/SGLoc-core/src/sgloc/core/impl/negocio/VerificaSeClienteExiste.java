package sgloc.core.impl.negocio;

import java.sql.SQLException;
import java.util.List;

import sgloc.core.IDAO;
import sgloc.core.IStrategy;
import sgloc.core.impl.dao.FilmeDAO;
import sgloc.dominio.Cliente;
import sgloc.dominio.EntidadeDominio;

public class VerificaSeClienteExiste implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		
		IDAO dao = new FilmeDAO();
		
		Cliente cliente = new Cliente();
		cliente.setNome(((Cliente) entidade).getNome());
		
		try {
			List<EntidadeDominio> entidades = dao.consultar(cliente);
			
			if(entidades.isEmpty())
				return null;
			
			for(EntidadeDominio entity : entidades){
				Cliente c = (Cliente) entity;
				
				if(cliente.getNome().equalsIgnoreCase(c.getNome())) //verifica se ha strings iguais
					return "O Cliente cadastrado já existe!";
			}
			
			return null;
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			return "Desculpe, alguma coisa estranha aconteceu";
		}
		
		
	}

}