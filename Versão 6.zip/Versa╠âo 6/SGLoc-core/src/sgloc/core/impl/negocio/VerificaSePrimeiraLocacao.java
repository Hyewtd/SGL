package sgloc.core.impl.negocio;

import java.sql.SQLException;

import sgloc.core.IStrategy;
import sgloc.core.impl.dao.LocacaoDAO;
import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Locacao;

public class VerificaSePrimeiraLocacao implements IStrategy{

	@Override
	public String processar(EntidadeDominio entidade) {
		// TODO Auto-generated method stub
	    Locacao locacao = (Locacao) entidade;
	    LocacaoDAO dao = new LocacaoDAO();
	    
	    try {
			if(dao.isPrimeiraLocacaoCliente(locacao)){
				if(locacao.getItens().size() > 2)
					return "Primeira Locação do Cliente";
			}
			
			return null;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Erro ao validar se primeira locacao";
		}
	}

}
