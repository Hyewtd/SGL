package sgloc.core.impl.negocio;

import java.sql.SQLException;
import java.util.List;

import sgloc.core.IDAO;
import sgloc.core.IStrategy;
import sgloc.core.impl.dao.FilmeDAO;
import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Filme;

public class VerificaSeFilmeExiste implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		
		IDAO dao = new FilmeDAO();
		
		Filme filme = new Filme();
		filme.setTitulo(((Filme) entidade).getTitulo());
		
		try {
			List<EntidadeDominio> entidades = dao.consultar(filme);
			
			if(entidades.isEmpty())
				return null;
			
			for(EntidadeDominio entity : entidades){
				Filme f = (Filme) entity;
				
				if(filme.getTitulo().equalsIgnoreCase(f.getTitulo())) //verifica se ha strings iguais
					return "O Filme cadastrado já existe!";
			}
			
			return null;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			return "Desculpe, alguma coisa estranha aconteceu";
		}
		
		
	}

}