package sgloc.core;

import sgloc.dominio.EntidadeDominio;

public interface IStrategy {

	public String processar(EntidadeDominio entidade);


}
