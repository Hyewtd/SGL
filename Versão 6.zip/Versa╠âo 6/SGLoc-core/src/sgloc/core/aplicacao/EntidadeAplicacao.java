package sgloc.core.aplicacao;

import sgloc.dominio.IEntidade;

public class EntidadeAplicacao implements IEntidade {

}
