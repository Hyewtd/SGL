package sgloc.core.aplicacao;

public class Mensagem {
	private String texto;
	public static final String ERROR = "error";
	public static final String SUCCESS = "success";
	private String tipo;
	
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	};	
}
