package sgloc.teste;

import java.util.Date;

import sgloc.core.IFachada;
import sgloc.core.impl.controle.Fachada;
import sgloc.dominio.Filme;
import sgloc.dominio.Fornecedor;
import sgloc.dominio.Midia;

public class TesteFilmeDAO {

	public static void main(String[] args) {

		Filme filme1 = new Filme();
		Fornecedor fr = new Fornecedor();

		filme1.setTitulo("Homem de Ferro");
		filme1.setTituloOriginal("The Martian");
		filme1.setAtorPrincipal("xxxx");
		filme1.setProdutora("20th Century Fox");
		filme1.setAnoLancamento("xxxxx");
		fr.setNome("Fornecedo Y");
		fr.setCnpj("1111111111111111111");
		filme1.setGenero("TESTE");
		filme1.setQntddEntrada(4);
		filme1.setCusto(12.90);
		filme1.setTotalCompra(51.60);
		filme1.setTotalDisponivel(4);
		filme1.setDtCadastro(new Date());
		filme1.setFornecedor(fr);
		filme1.setMidia(Midia.DVD);
		
		System.out.println("Id "+ filme1.getMidia());
		

		
		filme1.setId(1);
//		FilmeDAO dao = new FilmeDAO();
//		dao.salvar(filme1);
		
		 IFachada f = new Fachada();
		 f.salvar(filme1);

		// #####################################################################################

//		List<EntidadeDominio> filmes = dao.consultar(filme1);
//
//		for (EntidadeDominio f : filmes) {
//
//			Filme filme = (Filme) f;
//			System.out.println("\nID: " + filme.getId());
//			System.out.println("T�tulo: " + filme.getTitulo());
//			System.out.println("T�tulo Original: " + filme.getTituloOriginal());
//			System.out.println("Produtora: " + filme.getProdutora());
//			System.out.println("Dt de Cadastro" + filme.getDtCadastro());
//		}

	}
	
	public static boolean excluirFilem(){
		
		
		
		return false;
	}

}
