package sgloc.teste;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import sgloc.core.IDAO;
import sgloc.core.impl.dao.LocacaoDAO;
import sgloc.dominio.Cliente;
import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Filme;
import sgloc.dominio.Locacao;
import sgloc.dominio.Midia;
import sgloc.dominio.Status;

public class TesteLocacaoDAO {
	
	private static final LocacaoDAO dao = new LocacaoDAO();
	private static final Locacao locacao = new Locacao();
	
	public static void main(String args[]) throws SQLException, ClassNotFoundException{
		salvar();
		//isPrimeiraLocacaoCliente();
		//listar();
	}
	
	public static void salvar() throws SQLException, ClassNotFoundException{
	   
		Locacao locacao = new Locacao();
		locacao.setDataLocacao(Calendar.getInstance());
		locacao.setDataNormal(Calendar.getInstance().getTime());
		Cliente cliente = new Cliente();
		cliente.setId(2);
		locacao.setCliente(cliente);
		locacao.setTipoPagamento("Cartao Credito");
		locacao.setStatus(Arrays.asList(Status.PAGO,Status.AGUARGANDO_DEVOLUCAO));
		locacao.setDataDevolucao(Calendar.getInstance());
		
	
		
		for(int i = 0; i < 3; i++){
		  Filme f = new Filme();
		  f.setId(i+1);
		  f.setMidia(Midia.BLUERAY);
		  locacao.addItem(f);
	   }
		
		//IDAO dao = new LocacaoDAO();
		
		dao.salvar(locacao);
		
		System.out.println("Dados Salvos");
	}
//------------------------------------------------	
	
	public static void listar() throws SQLException
    {
        Locacao loc = new Locacao();
        Cliente cliente = new Cliente();
        
        int mes, ano;
        
        cliente.setId(1);
        loc.setCliente(cliente);
        
      Date dtLoc = Calendar.getInstance().getTime();  //pega a data atual se o usuario nao digitar nada!
        loc.setDataNormal(dtLoc);
        
        
        IDAO dao = new LocacaoDAO();
        
        List<EntidadeDominio> locacoes = dao.consultar(loc);
        
        for(EntidadeDominio ed : locacoes)
        {
            System.out.println("Nome Cliente: "+((Locacao)ed).getId()); 
            System.out.println("Data devolucao: " +((Locacao)ed).getDataLocacao());
            System.out.println("Data devolucao: " +((Locacao)ed).getDataDevolucao());
            System.out.println("Posicao " +((Locacao)ed).getStatus());
            System.out.println("Status " +((Locacao)ed).getStatus());
        }
    }
	
	//------------------------------
	
	/**
	 * 
	 * @throws SQLException
	 */
	public static void isPrimeiraLocacaoCliente() throws SQLException{
		
		Cliente cliente = new Cliente();
		
		cliente.setId(1);
		locacao.setCliente(cliente);
				
		System.out.println(dao.isPrimeiraLocacaoCliente(locacao));
	}
}
