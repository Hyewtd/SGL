package sgloc.teste;

import java.sql.Connection;
import java.sql.SQLException;

import sgloc.core.IDAO;
import sgloc.core.impl.dao.AbstractJdbcDAO;
import sgloc.core.impl.dao.EstoqueDAO;
import sgloc.dominio.Estoque;
import sgloc.dominio.Filme;
import sgloc.util.Conexao;

public class TesteEstoqueDAO {
	
	public static void main(String args[]) throws ClassNotFoundException, SQLException{
		salvar(); //salva um estoque
	}
	
	public static void salvar() throws ClassNotFoundException, SQLException{
	 Filme filme = new Filme();
	 filme.setId(3);
	 
	 Estoque estoque = new Estoque(filme,10,5);
	 
	 Connection conn = Conexao.getConnection();
	 
	 IDAO dao = new EstoqueDAO(conn,"","");
	 
	 try{
		 dao.salvar(estoque);
		 System.out.println("Dados Salvos");
	 }
	 catch(SQLException ex){
		 System.out.println(ex.getMessage());
		 ex.printStackTrace();
	 }
	 catch(Exception ex1){
		 ex1.printStackTrace();
	 }
	 finally {
		conn.close();
	}
	 
	}
}