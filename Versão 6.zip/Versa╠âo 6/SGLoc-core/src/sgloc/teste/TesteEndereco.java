package sgloc.teste;

import java.sql.SQLException;

import sgloc.core.impl.dao.EnderecoDAO;
import sgloc.dominio.Endereco;

public class TesteEndereco {

	public static void main(String[] args) {
		
		Endereco end = new Endereco();
		
        System.out.println("aqui");
        end.setLogradouro("Rua Salvador Ferreira"); 
        end.setCEP("08710680");
        end.setBairro("Centro");
        end.setEstado("Sao Paulo");  
        end.setCidade("Mogi das Cruzes"); 
        end.setNumero("404");
        
//        Cliente cli = new Cliente();
//        cli.setNome("Rodrigo");
//        cli.setCpf("1234567897");
        
        
        
        
        EnderecoDAO dao = new EnderecoDAO();
        
      
            try {
            	System.out.println("entrou TRY");
            	
				dao.salvar(end);
				 
//		            List<EntidadeDominio> entidades = dao.consultar(entrega);
//		            
//		            for (EntidadeDominio ed : entidades )
//		            {
//		                System.out.println("logradouro: "+((Endereco)ed).getLogradouro());
//		            }
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	

}
}
