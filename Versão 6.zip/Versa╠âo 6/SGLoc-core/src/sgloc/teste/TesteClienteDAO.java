package sgloc.teste;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import sgloc.core.IDAO;
import sgloc.core.impl.dao.ClienteDAO;
import sgloc.dominio.Cliente;
import sgloc.dominio.Endereco;

public class TesteClienteDAO {

	public static void main(String[] args) {

		Endereco end = new Endereco();

		System.out.println("aqui");
		end.setLogradouro("Rua Salvador Ferreira");
		end.setCEP("08710680");
		end.setBairro("Centro");
		end.setEstado("Sao Paulo");
		end.setCidade("Mogi das Cruzes");
		end.setNumero("404");

		Cliente cli = new Cliente();

		cli.setNome("Felipe Marques");
		cli.setCpf("87656789644");
		cli.setMail("felipe.marques@gmail.com");
		cli.setCelular("11 34256789");
		cli.setProfissao("Engenheiro");
		cli.setSexo("M");


		
		cli.setEndereco(end);

		Calendar c = Calendar.getInstance();
		c.set(1990, 11, 03);
		
		cli.setDtNasc(c);
		
		
		cli.setDtCadastro(new Date());

		IDAO dao = new ClienteDAO();

		try {

			dao.salvar(cli);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
