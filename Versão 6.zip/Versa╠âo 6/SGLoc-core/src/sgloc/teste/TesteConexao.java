package sgloc.teste;

import java.sql.Connection;
import java.sql.SQLException;

import sgloc.util.Conexao;

public class TesteConexao {

	public static void main(String[] args) {

		try {
			Connection conexao = Conexao.getConnection();

			if (conexao != null) {
				System.out.println("CONECTADO!!!");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}