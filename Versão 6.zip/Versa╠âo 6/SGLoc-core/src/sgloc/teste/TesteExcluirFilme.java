package sgloc.teste;

import java.sql.SQLException;

import sgloc.core.IDAO;
import sgloc.core.impl.dao.FilmeDAO;
import sgloc.dominio.Filme;

public class TesteExcluirFilme {

	public static void main(String[] args) {
		
		Filme f = new Filme();
		
		f.setId(52);
		
		IDAO fdao = new FilmeDAO();
		try {
			fdao.excluir(f);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
