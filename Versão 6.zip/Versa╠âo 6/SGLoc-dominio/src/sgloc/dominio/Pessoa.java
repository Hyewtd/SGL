package sgloc.dominio;

import java.util.Calendar;

public class Pessoa extends EntidadeDominio {

	private String nome;
	private Endereco endereco;
	public Calendar dtNasc;
	
	

	public Calendar getDtNasc() {
		return dtNasc;
	}

	public void setDtNasc(Calendar dtNasc) {
		this.dtNasc = dtNasc;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

}
