package sgloc.dominio;

public class ItemFilme extends EntidadeDominio {

	private Filme filme;

	public Filme getFilme() {
		return filme;
	}

	public void setFilme(Filme filme) {
		this.filme = filme;
	}

}
