package sgloc.dominio;

public enum Midia {
	
	DVD("DVD",2.50),BLUERAY("BLUERAY",5.00);
	
	private String descricao;
	private double valor;
    
	private Midia(String descricao, double valor){
		this.descricao = descricao;
		this.valor = valor;
	}
	
	public String getTipoMidia() {
		return descricao;
	}

	public void setTipoMidia(String tipoMidia) {
		this.descricao = tipoMidia;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}	
}
