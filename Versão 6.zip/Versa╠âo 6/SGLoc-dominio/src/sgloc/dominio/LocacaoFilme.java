package sgloc.dominio;

public class LocacaoFilme extends EntidadeDominio {

	private int idLocacao;
	private int idFilme;
	private int quantidade;
	private ItemFilme item;

	public int getIdLocacao() {
		return idLocacao;
	}

	public void setIdLocacao(int idLocacao) {
		this.idLocacao = idLocacao;
	}

	public int getIdFilme() {
		return idFilme;
	}

	public void setIdFilme(int idFilme) {
		this.idFilme = idFilme;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public ItemFilme getItem() {
		return item;
	}

	public void setItem(ItemFilme item) {
		this.item = item;
	}

}
