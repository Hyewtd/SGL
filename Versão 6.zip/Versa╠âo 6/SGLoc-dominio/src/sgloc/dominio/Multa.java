package sgloc.dominio;

public class Multa {

}
