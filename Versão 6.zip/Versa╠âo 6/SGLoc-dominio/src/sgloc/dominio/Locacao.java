package sgloc.dominio;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.omg.DynamicAny.DynAnySeqHelper;

public class Locacao extends EntidadeDominio {

	private Calendar dataLocacao;
	private Cliente cliente;
	private List<Filme> itens = new ArrayList<>(); // filmes a serem locados
	private String tipoPagamento; // Dinheiro || cartao Débito
	private Date dataNormal;
	private List<Status> status = new ArrayList<>(); // 0 - Pago || Aguardando pagamento
	//1 - Devolvido || Aguardando devolucao 
	private Calendar dataDevolucao;

	public Calendar getDataLocacao() {
		return dataLocacao;
	}

	public void setDataLocacao(Calendar dataLocacao) {
		this.dataLocacao = dataLocacao;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	//-------------------------------------------
	
	/*
	 * Encapsulamento
	 */
	 public void addItem(Filme item){
	        itens.add(item);
	 }
	
	public void addStatus(Status status){
		this.status.add(status);
	}
	 
	public List<Status> getStatus() {
		return status;
	}

	public void setStatus(List<Status> status) {
		this.status = status;
	}

	public List<Filme> getItens() {
		return itens; 
	} 

	public void setItens(List<Filme> itens) {
		this.itens = itens;
	}
	
	//----------------------------------------------

	public String getTipoPagamento() {
		return tipoPagamento;
	}

	public void setTipoPagamento(String tipoPagamento) {
		this.tipoPagamento = tipoPagamento;
	}

	public Date getDataNormal() {
		return dataNormal;
	}

	public void setDataNormal(Date dataNormal) {
		this.dataNormal = dataNormal;
	}


	public Calendar getDataDevolucao() { //strategy
		dataDevolucao.add(Calendar.DAY_OF_WEEK, +itens.size());	//calcula a data de devolucao
		return dataDevolucao;
	}

	public void setDataDevolucao(Calendar dataDevolucao) {
		this.dataDevolucao = dataDevolucao;
	}
	
	
	public double valorTotal() //strategy
    {
        double valor = 0;
		
        for(Filme filme : itens){
        	valor = filme.getMidia().getValor() * itens.size();
        }
        
        return valor;
    }

}
