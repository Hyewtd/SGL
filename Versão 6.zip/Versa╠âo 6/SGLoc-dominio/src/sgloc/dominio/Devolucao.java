package sgloc.dominio;

import java.util.Date;

public class Devolucao extends EntidadeDominio {

	private Locacao locacao;
	private Date dtAtual;
}
