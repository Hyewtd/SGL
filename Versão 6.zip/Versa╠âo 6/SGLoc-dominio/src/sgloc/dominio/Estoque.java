package sgloc.dominio;

import java.util.ArrayList;
import java.util.List;

public class Estoque extends EntidadeDominio{
	
	public Estoque() { }
	
	public Estoque(Filme filme, Integer qtdeFilme, Integer qtdeLocado) {
		super();
		this.filme = filme;
		this.qtdeFilme = qtdeFilme;
		this.qtdeLocado = qtdeLocado;
	}

	private Filme filme;
	private Integer qtdeFilme;
	private Integer qtdeLocado;
	private List<Filme> filmes = new ArrayList<>();
	
	public List<Filme> getFilmes() {
		return filmes;
	}

	public void setFilmes(List<Filme> filmes) {
		this.filmes = filmes;
	}

	public Filme getFilme() {
		return filme;
	}
	public void setFilme(Filme filme) {
		this.filme = filme;
	}
	public Integer getQtdeFilme() {
		return qtdeFilme;
	}
	public void setQtdeFilme(Integer qtdeFilme) {
		this.qtdeFilme = qtdeFilme;
	}
	public Integer getQtdeLocado() {
		return qtdeLocado;
	}
	public void setQtdeLocado(Integer qtdeLocado) {
		this.qtdeLocado = qtdeLocado;
	}
}
