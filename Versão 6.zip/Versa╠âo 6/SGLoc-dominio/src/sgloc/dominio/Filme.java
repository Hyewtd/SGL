package sgloc.dominio;

public class Filme extends EntidadeDominio {

	private String titulo;
	private String tituloOriginal;
	private String atorPrincipal;
	private String produtora;
	private String anoLancamento;
	private Fornecedor fornecedor;
	private String genero;
	private Midia midia;
	private Integer qntddEntrada;
	private Double custo;
	private Double totalCompra;
	private Integer totalDisponivel;
	private int status;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Fornecedor getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(Fornecedor fornecedor) {
		this.fornecedor = fornecedor;
	}

	public Midia getMidia() {
		return midia;
	}

	public void setMidia(Midia midia) {
		this.midia = midia;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getTituloOriginal() {
		return tituloOriginal;
	}

	public void setTituloOriginal(String tituloOriginal) {
		this.tituloOriginal = tituloOriginal;
	}

	public String getAtorPrincipal() {
		return atorPrincipal;
	}

	public void setAtorPrincipal(String atorPrincipal) {
		this.atorPrincipal = atorPrincipal;
	}

	public String getProdutora() {
		return produtora;
	}

	public void setProdutora(String produtora) {
		this.produtora = produtora;
	}

	public String getAnoLancamento() {
		return anoLancamento;
	}

	public void setAnoLancamento(String anoLancamento) {
		this.anoLancamento = anoLancamento;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public Integer getQntddEntrada() {
		return qntddEntrada;
	}

	public void setQntddEntrada(Integer qntddEntrada) {
		this.qntddEntrada = qntddEntrada;
	}

	public Double getCusto() {
		return custo;
	}

	public void setCusto(Double custo) {
		this.custo = custo;
	}

	public Double getTotalCompra() {
		return totalCompra;
	}

	public void setTotalCompra(Double totalCompra) {
		this.totalCompra = totalCompra;
	}

	public Integer getTotalDisponivel() {
		return totalDisponivel;
	}

	public void setTotalDisponivel(Integer totalDisponivel) {
		this.totalDisponivel = totalDisponivel;
	}

}
