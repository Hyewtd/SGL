package sgloc.dominio;

public class Cliente extends Pessoa {

	private String cpf;
	private String mail;
	private String celular;
	private String profissao;
	private String sexo;
	private int status; // ativo/inativo
	private int situacaoCliente; // indica a situacao de locacacoes do cliente;  // 0 = ainda nao realizou locação;
																				// 1 = locou e ainda não devolveu;
																				// 2 = sem pendências;

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	public String getProfissao() {
		return profissao;
	}

	public void setProfissao(String profissao) {
		this.profissao = profissao;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getSituacaoCliente() {
		return situacaoCliente;
	}

	public void setSituacaoCliente(int situacaoCliente) {
		this.situacaoCliente = situacaoCliente;
	}
	
	

}
