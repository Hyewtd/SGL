package sgloc.dominio;

public enum Status {
	// Pago || Aguardando pagamento
	PAGO("Pagamento Efetuado"),AGUARDANDO_PAGAMENTO("Aguardando Pagamento"),
	DEVOLVIDO("Filme Devolvido"),AGUARGANDO_DEVOLUCAO("Aguardando Devolução do Filme"),
	CLIENTESITUACAO("Cliente Situacao"),
	NOLOC("0"), // nunca efetuou locacoes
	YESLOC("1"), // efetuou locacoes e POSSUI pendencias
	OKLOC("2");// efetuou locacoes, porém NAO possui pendencias
	
	
	private String descricao;
	
	private Status(String descricao){
		this.descricao = descricao;
	}
	
	public String getDescricao(){
		return descricao;
	}
}
