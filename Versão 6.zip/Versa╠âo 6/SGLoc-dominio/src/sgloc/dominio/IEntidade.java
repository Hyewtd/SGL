package sgloc.dominio;

public interface IEntidade {

}
