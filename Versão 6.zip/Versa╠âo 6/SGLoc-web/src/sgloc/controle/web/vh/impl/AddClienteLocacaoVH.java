package sgloc.controle.web.vh.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sgloc.controle.web.vh.IViewHelper;
import sgloc.core.aplicacao.Resultado;
import sgloc.core.impl.dao.ClienteDAO;
import sgloc.dominio.Cliente;
import sgloc.dominio.EntidadeDominio;

public class AddClienteLocacaoVH implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setView(Resultado resultado, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		RequestDispatcher dispatcher = null;

		String operacao = request.getParameter("operacao");
		
		

		List<Cliente> clientes = new ArrayList<>();
		
		for (EntidadeDominio entidade : clientes) {
			Cliente c = (Cliente) entidade;

			clientes.add(c);
			
			request.getSession().setAttribute("clientes", resultado);
			request.getRequestDispatcher("FormLocacao.jsp").forward(request, response);

//			List<?> lista = (List<?>) resultado;
//			request.getSession().setAttribute("clientes", lista.get(0));
//			request.getRequestDispatcher("FormLocacao.jsp").forward(request, response);
//			
			// if (resultado.getMsg() == null) {
			// if (operacao.equals("AddCliente")) {
			// resultado.setMsg("Cliente ok");
			// }
			//
			// request.getSession().setAttribute("resultado", resultado);
			// dispatcher = request.getRequestDispatcher("FormLocacao.jsp");
			// }

		}

	}
}

