package sgloc.controle.web.vh.impl;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sgloc.controle.web.vh.IViewHelper;
import sgloc.core.aplicacao.Resultado;
import sgloc.dominio.Cliente;
import sgloc.dominio.Endereco;
import sgloc.dominio.EntidadeDominio;

public class ClienteVH implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		
		
		String operacao = request.getParameter("operacao");
		Cliente cliente = null;
		//Midia midia = null;
		
		if (!operacao.equals("VISUALIZAR")) {

			String txtLogr = request.getParameter("txtLogr");
			String txtCep = request.getParameter("txtCep");
			String txtBairro = request.getParameter("txtBairro");
			String txtEstado = request.getParameter("txtEstado");
			String txtCidade = request.getParameter("txtCidade");
			String txtNumero = request.getParameter("txtNumero");
			
			//DADOS CLIENTE
			String txtNome = request.getParameter("txtNome");
			String txtCpf = request.getParameter("txtCpf");
			String txtMail = request.getParameter("txtMail");
			String txtCelular = request.getParameter("txtCelular");
			String txtProf = request.getParameter("txtProf");
			
			
			String id = request.getParameter("txtId");
	//----------------------------------------------		
			Endereco end = new Endereco();
			end.setLogradouro(txtLogr);
			end.setCEP(txtCep);
			end.setBairro(txtBairro);
			end.setEstado(txtEstado);
			end.setCidade(txtCidade);
			end.setNumero(txtNumero);
			end.setDtCadastro(Calendar.getInstance().getTime()); //pegando a data atual
			
			
			cliente = new Cliente();
			
			if (txtNome != null && !txtNome.trim().equals("")) {
				cliente.setNome(txtNome);
			}

			if (txtCpf != null && !txtCpf.trim().equals("")) {
				cliente.setCpf(txtCpf);
			}

			if (txtMail != null && !txtMail.trim().equals("")) {
				cliente.setMail(txtMail);
			}

			if (txtCelular != null && !txtCelular.trim().equals("")) {
				cliente.setCelular(txtCelular);
			}

			if (txtProf != null && !txtProf.trim().equals("")) {
				cliente.setProfissao(txtProf);
			}

			
			cliente.setEndereco(end);
			

			//setando data de nascimento
	        //SimpleDateFormat simple = new SimpleDateFormat("YYYY-mm-dd");
	        DateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
	        java.util.Date dt = new Date();

	        if (request.getParameter("txtDtNasc") != null || !request.getParameter("txtDtNasc").equals(""))
	        {
	            try
	            {
	                dt = simple.parse(request.getParameter("txtDtNasc")); //pegando a data de nascimento
	            } catch (ParseException ex)
	            {
	                ex.printStackTrace();
	            }
	            cliente.setDtNasc(Calendar.getInstance());
	            cliente.getDtNasc().setTime(dt);
	        }
	        //se a data de nascimento for nula, o validador de campos deve capturar!
			
			
			cliente.setDtCadastro(Calendar.getInstance().getTime());	//pegando a data atual
			
			if (id != null && !id.trim().equals("")) {
				cliente.setId(Integer.parseInt(id));
			}
			
			

		} else {
			HttpSession session = request.getSession();
			Resultado resultado = (Resultado) session.getAttribute("resultado");
			String txtId = request.getParameter("txtId");
			int id = 0;

			if (txtId != null && !txtId.trim().equals("")) {
				id = Integer.parseInt(txtId);
			}
			
			
			for (EntidadeDominio e : resultado.getEntidades()) {
				if (e.getId() == id) {
					cliente = (Cliente) e;
				}
			}
		}

		return cliente;
	}


	@Override
	public void setView(Resultado resultado, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		RequestDispatcher dispatcher = null;

		String operacao = request.getParameter("operacao");
		
		if (resultado.getMsg() == null) {
			if (operacao.equals("SALVAR")) {
				resultado.setMsg("Cliente cadastrado com sucesso!");
			}

			request.getSession().setAttribute("resultado", resultado);
			dispatcher = request.getRequestDispatcher("FormConsultaCliente.jsp");
		}

		if (resultado.getMsg() == null && operacao.equals("ALTERAR")) {

			dispatcher = request.getRequestDispatcher("FormConsultaCliente.jsp");
		}

		if (resultado.getMsg() == null && operacao.equals("VISUALIZAR")) {

			request.setAttribute("cliente", resultado.getEntidades().get(0));
			dispatcher = request.getRequestDispatcher("FormCliente.jsp");
		}

		if (resultado.getMsg() == null && operacao.equals("EXCLUIR")) {

			request.getSession().setAttribute("resultado", null);
			dispatcher = request.getRequestDispatcher("FormConsultaCliente.jsp");
		}

		if (resultado.getMsg() != null) {
			if (operacao.equals("SALVAR") || operacao.equals("ALTERAR")) {
				request.getSession().setAttribute("resultado", resultado);
				dispatcher = request.getRequestDispatcher("FormConsultaCliente.jsp");
			}
		}

		dispatcher.forward(request, response);

	}

}
