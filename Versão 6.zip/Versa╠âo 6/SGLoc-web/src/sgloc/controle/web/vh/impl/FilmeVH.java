package sgloc.controle.web.vh.impl;

import java.io.IOException;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sgloc.controle.web.vh.IViewHelper;
import sgloc.core.aplicacao.Resultado;
import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Filme;
import sgloc.dominio.Fornecedor;
import sgloc.dominio.Midia;

public class FilmeVH implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {

		String operacao = request.getParameter("operacao");
		Filme filme = null;
		//Midia midia = null;
		
		if (!operacao.equals("VISUALIZAR")) {

			String titulo = request.getParameter("txtTitulo");
			String tituloOriginal = request.getParameter("txtTituloOriginal");
			String atorPrincipal = request.getParameter("txtAtorPr");
			String produtora = request.getParameter("txtProdutora");
			String anoLancamento = request.getParameter("txtAnoLanc");
			String nome = request.getParameter("txtNome");
			String cnpj = request.getParameter("txtCnpj");
			String genero = request.getParameter("txtGenero");
			
			
			Midia tipoMidia = request.getParameter("txtTipoMidia").equals("DVD") ? Midia.DVD : Midia.BLUERAY;
			String qntddEntrada = request.getParameter("txtQntdd");
			String custo = request.getParameter("txtCusto") == null ? "" : request.getParameter("txtCusto");
			String totalDisponivel = request.getParameter("txtTotalD");
			String id = request.getParameter("txtId");
			Double totalCompra = 0D;
			Double exCusto = request.getParameter("txtCusto") == null ? 0 : Double.valueOf(request.getParameter("txtCusto"));
			
			
			filme = new Filme();
			Fornecedor fornecedor = new Fornecedor();
			filme.setFornecedor(fornecedor);
			filme.setMidia(tipoMidia);
			
			if (titulo != null && !titulo.trim().equals("")) {
				filme.setTitulo(titulo);
			}

			if (tituloOriginal != null && !tituloOriginal.trim().equals("")) {
				filme.setTituloOriginal(tituloOriginal);
			}

			if (atorPrincipal != null && !atorPrincipal.trim().equals("")) {
				filme.setAtorPrincipal(atorPrincipal);
			}

			if (produtora != null && !produtora.trim().equals("")) {
				filme.setProdutora(produtora);
			}

			if (anoLancamento != null && !anoLancamento.trim().equals("")) {
				filme.setAnoLancamento(anoLancamento);
			}

			if (nome != null && !nome.trim().equals("")) {
				filme.getFornecedor().setNome(nome);
			}

			if (cnpj != null && !cnpj.trim().equals("")) {
				filme.getFornecedor().setCnpj(cnpj);
			}

			if (genero != null && !genero.trim().equals("")) {
				filme.setGenero(genero);
			}
			
			if (tipoMidia != null && !tipoMidia.equals("")) {
				filme.setMidia(tipoMidia);
			}
			
//			if(tipoMidia !=null);
//			midia.setTipoMidia(tipoMidia);
//				tipoMidia.setTipoMidia(filme);

			
			if (qntddEntrada != null && !qntddEntrada.trim().equals("")) {
				filme.setQntddEntrada(Integer.parseInt(qntddEntrada));
				filme.setTotalDisponivel(Integer.valueOf(qntddEntrada));
			}

			if (custo != null && !custo.trim().equals("")) {
				filme.setCusto(Double.parseDouble(custo));
			}
			
			if(!custo.equals("") && !qntddEntrada.equals("") && operacao.equals("SALVAR")){
				totalCompra = Double.valueOf(custo) * Double.valueOf(qntddEntrada);
				filme.setTotalCompra(totalCompra);
			}
			
			filme.setDtCadastro(Calendar.getInstance().getTime());	//pegando a data atual
			
			if (id != null && !id.trim().equals("")) {
				filme.setId(Integer.parseInt(id));
			}
			
			

		} else {
			HttpSession session = request.getSession();
			Resultado resultado = (Resultado) session.getAttribute("resultado");
			String txtId = request.getParameter("txtId");
			int id = 0;

			if (txtId != null && !txtId.trim().equals("")) {
				id = Integer.parseInt(txtId);
			}
			
			/*String titulo = request.getParameter("txtTitulo");
			filme = new Filme();
			filme.setTitulo(titulo);
			filme.setId(id);*/
			
			for (EntidadeDominio e : resultado.getEntidades()) {
				if (e.getId() == id) {
					filme = (Filme) e;
				}
			}
		}

		return filme;
	}

	// -----------------------------------------------------------------------------------------------------------
	@Override
	public void setView(Resultado resultado, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		RequestDispatcher dispatcher = null;

		String operacao = request.getParameter("operacao");
		
		if (resultado.getMsg() == null) {
			if (operacao.equals("SALVAR")) {
				resultado.setMsg("Filme cadastrado com sucesso!");
			}

			request.getSession().setAttribute("resultado", resultado);
			dispatcher = request.getRequestDispatcher("FormConsultaFilme.jsp");
		}

		if (resultado.getMsg() == null && operacao.equals("ALTERAR")) {

			dispatcher = request.getRequestDispatcher("FormConsultaFilme.jsp");
		}

		if (resultado.getMsg() == null && operacao.equals("VISUALIZAR")) {

			request.setAttribute("filme", resultado.getEntidades().get(0));
			dispatcher = request.getRequestDispatcher("FormFilme.jsp");
		}

		if (resultado.getMsg() == null && operacao.equals("EXCLUIR")) {

			request.getSession().setAttribute("resultado", null);
			dispatcher = request.getRequestDispatcher("FormConsultaFilme.jsp");
		}

		if (resultado.getMsg() != null) {
			if (operacao.equals("SALVAR") || operacao.equals("ALTERAR")) {
				request.getSession().setAttribute("resultado", resultado);
				dispatcher = request.getRequestDispatcher("FormConsultaFilme.jsp");
			}
		}

		dispatcher.forward(request, response);

	}
	
	/**
	 * Esse m�todo apenas pega as informa��es do salvar e colocar no objeto
	 * @param request
	 * @param response
	 */
	public void SalvarFilme(HttpServletRequest request, HttpServletResponse response)
	{
		
	}

}