package sgloc.controle.web.vh.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sgloc.controle.web.vh.IViewHelper;
import sgloc.core.aplicacao.Resultado;
import sgloc.core.impl.controle.Fachada;
import sgloc.dominio.Cliente;
import sgloc.dominio.EntidadeDominio;
import sgloc.dominio.Filme;
import sgloc.dominio.Locacao;
import sgloc.dominio.Midia;
import sgloc.dominio.Status;

public class LocacaoVH implements IViewHelper {

	
	private Cliente cliente = new Cliente();
	
	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		
		String operacao = request.getParameter("operacao");
		Locacao loc = null;
		Filme filme = null;
		
		if (!operacao.equals("VISUALIZAR")) {
			
			
			String nomeCliente = request.getParameter("txtCliente");
			String txtfilme = request.getParameter("txtFilme");
			String tipoPag = request.getParameter("txtTipoPag");
			Status status = request.getParameter("txtStatus").equals("PAGO") ? Status.PAGO : Status.AGUARDANDO_PAGAMENTO;
			Status status1 = request.getParameter("txtStatus1").equals("AGUARGANDO_DEVOLUCAO") ? status.AGUARGANDO_DEVOLUCAO : Status.DEVOLVIDO;
			
			
			//Pegando dados do Cliente - setando o cliente na locacao
			Cliente cli = new Cliente();
			//loc.setCliente(cli);
			
			
			
			if (nomeCliente != null && !nomeCliente.trim().equals("")) {
				cli.setNome(nomeCliente);
				loc.setCliente(cli);
			}
			
//			for(int i = 0; i < 3; i++){
//				  Filme f = new Filme();
//				  f.setId(i+1);
//				  f.setMidia(Midia.BLUERAY); 
//				  filme.setTitulo(txtfilme);
//				  loc.addItem(filme);
//				  loc.setItens(Arrays.asList(filme,filme,filme));
//			   }

			if (tipoPag != null && !tipoPag.trim().equals("")) {
				loc.setTipoPagamento(tipoPag);
			}

			if (status != null && !status.equals("") && status1 != null && !status1.equals("")) {
				loc.setStatus(Arrays.asList(status,status1));
			}
			
			loc.setDataLocacao(Calendar.getInstance());
			loc.setDataNormal(Calendar.getInstance().getTime());
			
			loc.setDataDevolucao(Calendar.getInstance());
			
			
			loc.setDtCadastro(Calendar.getInstance().getTime());	//pegando a data atual
			
//			if (id != null && !id.trim().equals("")) {
//				filme.setId(Integer.parseInt(id));
//			}
			
			

		} else {
			HttpSession session = request.getSession();
			Resultado resultado = (Resultado) session.getAttribute("resultado");
			String txtId = request.getParameter("txtId");
			int id = 0;

			if (txtId != null && !txtId.trim().equals("")) {
				id = Integer.parseInt(txtId);
			}
			
			/*String titulo = request.getParameter("txtTitulo");
			filme = new Filme();
			filme.setTitulo(titulo);
			filme.setId(id);*/
			
			if(resultado != null){
			
				for (EntidadeDominio e : resultado.getEntidades()) {
					if (e.getId() == id) {
						loc = (Locacao) e;
					}
				}
				
			}
			
			
		}

		return loc;
	}

	@Override
	public void setView(Resultado resultado, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		RequestDispatcher dispatcher = null;

		String operacao = request.getParameter("operacao");
		
		
		if (resultado.getMsg() == null) {
			if (operacao.equals("SALVAR")) {
				resultado.setMsg("Locaçao realizada com sucesso!");
			}

			request.getSession().setAttribute("resultado", resultado);
			dispatcher = request.getRequestDispatcher("FormConsultaLoc.jsp");
		}

		if (resultado.getMsg() == null && operacao.equals("ALTERAR")) {

			dispatcher = request.getRequestDispatcher("FormConsultaLoc.jsp");
		}

		if (resultado.getMsg() == null && operacao.equals("VISUALIZAR")) {
			
			Fachada fachada = new Fachada();
			String cpf = request.getParameter("txtCpf");
			//TODO validar o CPF
			cliente.setId(1);
			cliente.setCpf(cpf);
			Resultado rsCliente = fachada.consultar(cliente); //pegou os dados do cliente
			Filme filme = new Filme();
			filme.setTitulo("");
			Resultado rsFilme = fachada.consultar(new Filme());
			
			Locacao loc  = new Locacao();
			
			loc.setCliente((Cliente) rsCliente.getEntidades().get(0));
			loc.setItens(new ArrayList<Filme>());
			
			for(EntidadeDominio entidade : rsFilme.getEntidades()){
				Filme f = new Filme();
				loc.getItens().add(f); 
			}
			rsFilme = fachada.consultar(filme);
			request.setAttribute("locacao", loc);
			dispatcher = request.getRequestDispatcher("FormLocacao.jsp");
		}

		if (resultado.getMsg() == null && operacao.equals("EXCLUIR")) {

			request.getSession().setAttribute("resultado", null);
			dispatcher = request.getRequestDispatcher("FormConsultaLoc.jsp");
		}

		if (resultado.getMsg() != null) {
			if (operacao.equals("SALVAR") || operacao.equals("ALTERAR")) {
				request.getSession().setAttribute("resultado", resultado);
				dispatcher = request.getRequestDispatcher("FormConsultaLoc.jsp");
			}
		}

		dispatcher.forward(request, response);

	}

	

}
