package sgloc.controle.web.command.impl;

import sgloc.core.aplicacao.Resultado;
import sgloc.dominio.EntidadeDominio;

public class VisualizarCommand extends AbstractCommand {

	@Override
	public Resultado execute(EntidadeDominio entidade) {
		
		return fachada.visualizar(entidade);
	}

}
