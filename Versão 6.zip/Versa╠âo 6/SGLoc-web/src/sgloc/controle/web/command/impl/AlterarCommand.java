package sgloc.controle.web.command.impl;

import sgloc.core.aplicacao.Resultado;
import sgloc.dominio.EntidadeDominio;

public class AlterarCommand extends AbstractCommand{
	
	public Resultado execute(EntidadeDominio entidade) {
		
		return fachada.alterar(entidade);
	}
}
