package sgloc.controle.web.command.impl;

import sgloc.core.aplicacao.Resultado;
import sgloc.dominio.EntidadeDominio;

public class ConsultarCommand extends AbstractCommand {

	@Override
	public Resultado execute(EntidadeDominio entidade) {
		
		return fachada.consultar(entidade);
	}

}
