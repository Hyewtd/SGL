package sgloc.controle.web.command.impl;

import sgloc.controle.web.command.ICommand;
import sgloc.core.IFachada;
import sgloc.core.impl.controle.Fachada;

public abstract class AbstractCommand implements ICommand{
	
	protected IFachada fachada = new Fachada();

}
