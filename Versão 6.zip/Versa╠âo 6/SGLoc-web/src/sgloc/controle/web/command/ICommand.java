package sgloc.controle.web.command;

import sgloc.core.aplicacao.Resultado;
import sgloc.dominio.EntidadeDominio;

public interface ICommand {

	public Resultado execute(EntidadeDominio entidade);
	
}
