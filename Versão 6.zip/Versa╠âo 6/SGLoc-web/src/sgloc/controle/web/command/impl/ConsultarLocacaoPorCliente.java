package sgloc.controle.web.command.impl;

import sgloc.core.aplicacao.Resultado;
import sgloc.core.impl.controle.Fachada;
import sgloc.dominio.EntidadeDominio;

public class ConsultarLocacaoPorCliente extends AbstractCommand {

	Fachada f = (Fachada) fachada; // downcasting
	
	
	@Override
	public Resultado execute(EntidadeDominio entidade) {
		
		return f.consultarLocacaoPorCliente(entidade);
	}

}
