package sgloc.controle.web.command.impl;

import sgloc.core.aplicacao.Resultado;
import sgloc.dominio.EntidadeDominio;

public class ExcluirCommand extends AbstractCommand {

	@Override
	public Resultado execute(EntidadeDominio entidade) {
		
		return fachada.excluir(entidade);
	}

}
